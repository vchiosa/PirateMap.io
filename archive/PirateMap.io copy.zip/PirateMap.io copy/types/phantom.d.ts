interface Window {
  solana?: any;
}
